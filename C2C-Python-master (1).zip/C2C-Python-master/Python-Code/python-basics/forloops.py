# for i in range(11):
#     print(i,end=" ")

# for i in range(1,101):  #(start, stop-1)
#     print(i)


# for i in range(0,101,5): #(start,stop-1,stepsize-1) 
#     print(i) #0, 5, 10, 15, ..... 95,100

# for i in range(-10,0): 
#     print(i)


# n=int(input("Enter the table number to print\n"))
# for i in range(1,11):
#     print(n,"X",i,"=",n*i)
