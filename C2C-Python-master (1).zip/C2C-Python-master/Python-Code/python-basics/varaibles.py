companyname='GUVI'
since=2014
country='INDIA'
print(companyname)
print(since,country)

# company_Name='guvi'
# FIRSTNAME=''

# 1name='ark'

# name&%@&U@(*@*)

# _name='ark'
# print(_name)

# firstname123='ark'
