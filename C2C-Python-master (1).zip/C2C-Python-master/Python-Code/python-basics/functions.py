# # def func1():
# #     print("i am function 1")
# #     func2()

# # def func2():
# #     print(" i am function 2")

# # func1()
# def employeeDetails():
#     company="Infosys"
#     print("Rohan is working at",company)
    
# def greeting():
#     print("Good Morning")



# employeeDetails()
# greeting()
