# s=set()
# s.add(1)
# s.add(2)
# s.add(3)
# print(s,type(s))
# # print(s[2])

# s1={1,2,3,4,5}
# s2={4,5,6,7,8,9}
# s3={10,11,12,13,4,5}
# print(s1.union(s2).union(s3))
# print(s1)
# # s1=s1.union(s2).union(s3)
# print(s1.intersection(s2).intersection(s3))

# s1.pop()
# s1.pop()
# s1.pop()
# print(s1)

# s2.remove(8)
# print(s2)

# 1. Write a Python program that takes a list of integers as input and prints the unique elements in the list.?
#  2. Implement Union & intersection operation on it.

# list1=[1,2,3,4,5]
# list2=[3,4,5,6,7]

# set1=set(list1)
# set2=set(list2)

# print(set1.intersection(set2))