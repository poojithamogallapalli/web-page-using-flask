# # # And-or-not
# # True=1
# # False=0

# # And -> multiplication
# # Or  --> Addition

# print(True and True) 
# print(True and False)
# print(False and True)
# print(False and False)


# # # or
# print("or\n")
# print(True or True)
# print(True or False)
# print(False or True)
# print(False or False)

# print('data')
# print((True or True or False  or True or False) and (True and False) and (True or False))

# a=10
# b=20
# c=30
# d=40
# print("\n")
# print(a<=b and c>=d)
# # print(True and False)
# print(a<=b and c<=d)

# print("\n")
# print("or",a<=b or c>=d)
# # print(True or False)
# print("or",a<=b or c<=d)
# print("or",a>b or c>d)

# # not
# print(not True)
# print(not False)

# print("Identity operator")
# is and is not
# print(2 is 3)
# print(2 is not 3)
# print(2 is '2')

# a=12
# b=12
# print( a is b)

# print("membership opeartor")
a=[1,2,3]
print(1 in a)
print(20 not in a)

# # bitwise
print(1 | 1)
print(1 & 1)
print(1 & 0)
print(1 & 1 & 1& 0)
print(1 | 0 | 0 | 0 | 0)