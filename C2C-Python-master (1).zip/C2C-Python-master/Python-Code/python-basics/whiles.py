# i=1
# while(i<=5):
#     print(i)
#     i+=1
    

# i=1
# while(i<=5):
#     if(i==3):
#         break
#     print(i)
#     i=i+1


# if 2>1:
#     pass
# else:
#     print('ok')