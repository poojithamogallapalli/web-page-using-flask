# mylist=['anees','meghana','amrutha','aneeqah','aadithyaa','harshith']
# mylist.sort()
# print(mylist)
# mylist.remove('anees')
# print(mylist)
# print("positive slicing")
myslice=[1,2,4,6,7,9,10]
# print(myslice[:])
# print(myslice[1:])
# print(myslice[:5])
# print(myslice[3:7])

# print("negative slicing")
# myslice=[1,2,4,6,7,9,10]
# print(myslice[-5:])
# print(myslice[1:-3]) #(2,4,6)  [start:end-1] [1:-3-1] [1:-4]
# print(myslice[:-1])
# print(myslice[-5:-2])

myslice=[1,2,4,6,7,9,10]
# print(myslice[::2])  #[start,end-1,step-size-1]
# print(myslice[1:4:2])
# print(myslice[::4])
print(myslice[::-1])
print(myslice[::-2])
print(myslice[::2])
