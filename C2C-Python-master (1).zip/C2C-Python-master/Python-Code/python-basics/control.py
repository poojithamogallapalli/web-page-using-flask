# a="guvi"
# b="guvi"
# if(a!=b):
#     print("i am inside if block")
# else:
#     print("i am else part")
# print(" i am outside else if")

# a=10
# b=20
# if(a>b): #false

#     print("I am if block")
#     print("Yes a is less than b")
#     print("thank you")

# print("i am outside the if block i dont have any connection with above if block")
# sum=a+b
# print("sum is" ,sum)