firstName='Guvi'
since=2014
salary=35002.50
data="this is python"
summary='''hey how are you'''
phoneNumber='9999999999'

# print(type(firstName))
# print(type(since))
# print(type(salary))
# print(type(data))
# print(type(summary))
# print(type(phoneNumber))

'''
mylist=[1,2,3,4,5,'a','b','c',['bat','wickets']]
print(type(mylist))
print(mylist)
print(mylist[3])
print(mylist[8][0])
'''

'''
myset={1,2,4,1,2,3,5,6,7}
print(type(myset))
print(myset)
'''

# dictionary
# key-value pairs 

'''
mydata={
    "name":"ark",
    "role":"FSD",
    "phoneNumber":9874569874569,
    "skills":['python','java','javascript'],
    "interests":{'cricket','carrom'},
    "salary":32500.25,
    "data":{
        "fname":"a",
        "lname":"b"
    }
}

print(mydata)
print(type(mydata))

'''

# tuple
# mytup=(1,2,3,4,5)
# print(type(mytup))


# myboool=True
# mybol2=False
# print(type(myboool))
# print(type(mybol2))

# a=None
# print(type(a))


data=[1,2,3]
data[1]=20
print(data) 

data=(1,2,3)
print(data[1])
data[1]=20 #failed
print(data)