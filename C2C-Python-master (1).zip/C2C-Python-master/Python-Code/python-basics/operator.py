# a=10
# a+=20 #a=a+20 #a=10+20
# print(a)

# a/=10 #a=a/10 a=30/10
# print(a)

# a**=3 #a=3*3*3
# print(a)

# b=10
# c=20
# print(b%c)

# b=30
# c=4
# print(b%c)
# comparison operators


# print(12<20)
# print(12>20)

a=10
b=10
c='10'
print(a==b)
print(a==c)

v=10
print(c!=v)
print(a<=v)
print(b>=v)