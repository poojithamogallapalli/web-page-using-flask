# def minus(a,b):
#     return a-b

# output=minus(10,5)
# print(output)

minus=lambda x,y:x-y
add=lambda x,y:x+y
div=lambda x,y:x/y
mul=lambda x,y,z:x*y*z
print(minus(10,5))
print(add(10,5))
print(div(10,5))
print(mul(10,5,2))