class Data:

    name="guvi" #public
    _email="guvi@gmail.com" #protected
    __password="123***" #private

obj1=Data()
print(obj1.name)   
print(obj1._email)   
print(obj1._Data__password)   
