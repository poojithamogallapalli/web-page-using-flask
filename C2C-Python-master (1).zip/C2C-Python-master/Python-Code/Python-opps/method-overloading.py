class Calcy:
    def add(self,a,b,c,d):
        return a+b+c+d
    
obj=Calcy()

print(obj.add(10,20))
print(obj.add(10,20,30))
print(obj.add(10,20,30,40))

# class Calculator:
#     def add (self,*args):
        
#         res=0
#         for n in args:
#             res+=n
#         return res
    
# obj=Calculator()
# print(obj.add(1,2))
# print(obj.add(1,2,3))
# print(obj.add(1,2,3,4))
# print(obj.add(1,2,3,4,5))
# print(obj.add(1,2,3,4,5,6))
# print(obj.add(1,2,3,4,5,6,7))
# print(obj.add(1,2,3,4,5,6,7,8))

