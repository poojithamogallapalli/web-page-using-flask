pip install virtualenv

python -m virtulenv myenv

myenv\Scripts\activate

pip install -r requirements.txt

python main.py




// to pack the modules in requirements.txt file 

pip freeze >requirements.txt



create a new folder ->create main.py add code 
run server -> python main.py

->in virtual environment you are doing this

whenever we run the program we need to activate the virtual env 
first (myenv) then we need to start the program
_______________________________

pip install flask 

->its in global level

create folder->main.py->add the code -> run the pprogram


HTML->class -> CSS is loaded from cdn based on class name
HTML->id-> Javascript is loaded from cdn based on ids


<!-- 
below command for installations

 -->

pip install -r requirements.txt